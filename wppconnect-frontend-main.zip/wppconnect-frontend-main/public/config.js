window.IP_SERVER = "http://192.168.15.46:21465/api/";
window.IP_SOCKET_IO = "http://192.168.15.46:21465/";
