## 1.0.1 (2021-07-14)


### Bug Fixes

* Removido dependências diretas de pacotes de terceiro ([5b4b62e](https://github.com/wppconnect-team/wppconnect-frontend/commit/5b4b62ec71904fcfb21e76b4c8a844d45ee48c30))



# 1.0.0 (2021-06-12)



